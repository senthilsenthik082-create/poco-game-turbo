package com.sujin.pocogameturbo;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView tempValue, batteryValue, statusValue;
    private final Handler handler = new Handler();
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateBatteryInfo();
            handler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,16,16));
        getWindow().setNavigationBarColor(Color.rgb(16,16,16));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(16,16,16));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(root);

        TextView brand = text("POCO  GAME TURBO", 24, Color.WHITE, true);
        root.addView(brand);
        TextView sub = text("GAMING CONTROL • VERSION 1.0", 11, Color.LTGRAY, true);
        sub.setPadding(0, dp(5), 0, dp(20));
        root.addView(sub);

        LinearLayout panel = card();
        root.addView(panel);
        panel.addView(text("DEVICE STATUS", 13, Color.LTGRAY, true));
        tempValue = text("-- °C", 34, Color.WHITE, true);
        tempValue.setPadding(0, dp(10), 0, 0);
        panel.addView(tempValue);
        batteryValue = text("Battery: --%", 14, Color.LTGRAY, false);
        panel.addView(batteryValue);
        statusValue = text("Checking battery temperature…", 13, Color.LTGRAY, false);
        statusValue.setPadding(0, dp(8), 0, 0);
        panel.addView(statusValue);

        Button launch = button("▶   LAUNCH FREE FIRE");
        root.addView(launch);
        launch.setOnClickListener(v -> launchFreeFire());

        Button lowHeat = button("❄   LOW HEAT TIPS");
        root.addView(lowHeat);
        lowHeat.setOnClickListener(v -> showMessage(
            "LOW HEAT MODE\\n\\n• Use Smooth graphics in Free Fire.\\n• Close unused apps before playing.\\n• Reduce screen brightness.\\n• Avoid playing while charging.\\n• Remove a thick phone case during long sessions.\\n• Stop playing if the phone becomes uncomfortably hot."));

        Button settings = button("⚙   OPEN DISPLAY SETTINGS");
        root.addView(settings);
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));

        LinearLayout guide = card();
        root.addView(guide);
        guide.addView(text("HEADSHOT SENSITIVITY STARTER", 13, Color.LTGRAY, true));
        guide.addView(text("General        95–100\\nRed Dot        90–95\\n2× Scope       85–90\\n4× Scope       75–85\\nSniper         50–60\\nFree Look      70–80", 16, Color.WHITE, true));
        TextView note = text("Starting suggestions only. Adjust in Training Ground to suit your touch and screen.", 12, Color.LTGRAY, false);
        note.setPadding(0, dp(10), 0, 0);
        guide.addView(note);

        TextView limitation = text(
            "IMPORTANT: This app monitors the battery temperature reported by Android and provides safe tips. It cannot physically cool the phone, force extra FPS, change Free Fire aim, or boost hardware in the background. Android does not allow ordinary apps to freely kill other apps or control CPU/GPU performance.",
            12, Color.LTGRAY, false);
        limitation.setPadding(dp(2), dp(18), dp(2), 0);
        root.addView(limitation);

        setContentView(scroll);
        updateBatteryInfo();
    }

    private void updateBatteryInfo() {
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) return;
        int rawTemp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        float celsius = rawTemp >= 0 ? rawTemp / 10f : -1;
        int percent = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;

        tempValue.setText(celsius >= 0 ? String.format(java.util.Locale.getDefault(), "%.1f °C", celsius) : "Unavailable");
        batteryValue.setText("Battery: " + (percent >= 0 ? percent + "%" : "Unavailable"));
        if (celsius < 0) statusValue.setText("Battery temperature not provided by this device.");
        else if (celsius >= 42) statusValue.setText("High battery temperature — stop gaming and let the phone cool.");
        else if (celsius >= 38) statusValue.setText("Warm — lower graphics and take a short break.");
        else statusValue.setText("Temperature looks normal. Check again during gameplay.");
    }

    private void launchFreeFire() {
        String[] packages = {"com.dts.freefireth", "com.dts.freefiremax"};
        for (String pkg : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) { startActivity(launch); return; }
        }
        showMessage("Free Fire was not found. Install the game first, then try again.");
    }

    private void showMessage(String message) {
        new android.app.AlertDialog.Builder(this)
            .setTitle("POCO GAME TURBO")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show();
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackgroundColor(Color.rgb(32,32,32));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(16);
        box.setLayoutParams(lp);
        return box;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(205,45,45)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.bottomMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override protected void onResume() { super.onResume(); handler.post(refresh); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(refresh); }
}
