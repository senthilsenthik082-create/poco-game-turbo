POCO GAME TURBO v1.0 — Android Studio starter project

WHAT IT DOES
- Installs as a normal home-screen Android app.
- Opens Free Fire / Free Fire MAX if installed.
- Displays Android-reported battery temperature and battery percentage while the app is open.
- Provides low-heat advice and a starter sensitivity guide.

IMPORTANT LIMITATIONS
- This is not an official Xiaomi/POCO Game Turbo component.
- It does not run a hidden performance service, overclock the phone, change CPU/GPU settings,
  force higher FPS, close other apps, or guarantee easier headshots.
- Battery temperature is not the same as exact CPU/GPU temperature and may be unavailable
  or delayed on some devices.
- Sensitivity values are starting points; tune them in the game's training area.

BUILD
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Let Gradle sync complete (Android Gradle Plugin 8.7.3; JDK 17 recommended).
4. Connect the POCO C55 with USB debugging enabled, or choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your phone.

Package: com.sujin.pocogameturbo
Minimum Android: 6.0 (API 23)
Target SDK: 35
